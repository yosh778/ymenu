/*
 * SaveData En/Decrypter on PC (GPLv3+)
 * kirk-engine (C) draan / proxima
 * jpcsp (C) jpcsp team, especially CryptoEngine by hykem
 * ported by PopsDeco
 */

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "kirk_engine.h"

#define arraycopy(src,srcPos,dest,destPos,len) memcpy((dest)+(destPos),(src)+(srcPos),(len))

typedef unsigned char byte;

#if defined(WIN32) || (!defined(__GNUC__) && !defined(__clang__))
	#define initstdio() setmode(fileno(stdin),O_BINARY),setmode(fileno(stdout),O_BINARY),setmode(fileno(stderr),O_BINARY);
#else
	#define initstdio()
	int filelength(int fd){ //constant phrase
		struct stat st;
		fstat(fd,&st);
		return st.st_size;
	}
#endif

byte sdHashKey1[16] = {0x40, 0xE6, 0x53, 0x3F, 0x05, 0x11, 0x3A, 0x4E, 0xA1, 0x4B, 0xDA, 0xD6, 0x72, 0x7C, 0x53, 0x4C};
byte sdHashKey2[16] = {0xFA, 0xAA, 0x50, 0xEC, 0x2F, 0xDE, 0x54, 0x93, 0xAD, 0x14, 0xB2, 0xCE, 0xA5, 0x30, 0x05, 0xDF};
byte sdHashKey3[16] = {0x36, 0xA5, 0x3E, 0xAC, 0xC5, 0x26, 0x9E, 0xA3, 0x83, 0xD9, 0xEC, 0x25, 0x6C, 0x48, 0x48, 0x72};
byte sdHashKey4[16] = {0xD8, 0xC0, 0xB0, 0xF3, 0x3E, 0x6B, 0x76, 0x85, 0xFD, 0xFB, 0x4D, 0x7D, 0x45, 0x1E, 0x92, 0x03};
byte sdHashKey5[16] = {0xCB, 0x15, 0xF4, 0x07, 0xF9, 0x6A, 0x52, 0x3C, 0x04, 0xB9, 0xB2, 0xEE, 0x5C, 0x53, 0xFA, 0x86};
byte sdHashKey6[16] = {0x70, 0x44, 0xA3, 0xAE, 0xEF, 0x5D, 0xA5, 0xF2, 0x85, 0x7F, 0xF2, 0xD6, 0x94, 0xF5, 0x36, 0x3B};
byte sdHashKey7[16] = {0xEC, 0x6D, 0x29, 0x59, 0x26, 0x35, 0xA5, 0x7F, 0x97, 0x2A, 0x0D, 0xBC, 0xA3, 0x26, 0x33, 0x00};

typedef struct{
	int mode;
	int unk;
	unsigned char buf[16];
} _SDCtx1, *SDCtx1;

typedef struct{
	int mode;
	unsigned char key[16];
	unsigned char pad[16];
	unsigned int padSize;
} _SDCtx2, *SDCtx2;

    void ScrambleSD(byte *buf, int size, int seed, int cbc, int kirk) {
        // Set CBC mode.
        *(int*)(buf)=cbc;
#if 0
        buf[0] = 0;
        buf[1] = 0;
        buf[2] = 0;
        buf[3] = (byte) cbc;
#endif
        // Set unkown parameters to 0.
        buf[4] = 0;
        buf[5] = 0;
        buf[6] = 0;
        buf[7] = 0;

        buf[8] = 0;
        buf[9] = 0;
        buf[10] = 0;
        buf[11] = 0;

        // Set the the key seed to seed.
        *(int*)(buf+12)=seed;
#if 0
        buf[12] = 0;
        buf[13] = 0;
        buf[14] = 0;
        buf[15] = (byte) seed;
#endif
        // Set the the data size to size.
        buf[16] = (byte) ((size >> 24) & 0xFF);
        buf[17] = (byte) ((size >> 16) & 0xFF);
        buf[18] = (byte) ((size >> 8) & 0xFF);
        buf[19] = (byte) (size & 0xFF);

        sceUtilsBufferCopyWithRange(buf, size, buf, size, kirk);
    }

     int hleSdSetIndex(SDCtx2 ctx, int encMode) {
        // Set all parameters to 0 and assign the encMode.
        ctx->mode = encMode;
        return 0;
    }

     int hleSdCreateList(SDCtx1 ctx, int encMode, int genMode, byte *data, byte *key) {
        // If the key is not a 16-byte key, return an error.
        //if (key.length < 0x10) {
        //    return -1;
        //}
        int i;

        // Set the mode and the unknown parameters.
        ctx->mode = encMode;
        ctx->unk = 0x1;

        // Key generator mode 0x1 (encryption): use an encrypted pseudo random number before XORing the data with the given key.
        if (genMode == 0x1) {
            unsigned char header[0x10 + 0x14];
            byte random[0x14];
            byte newKey[0x10];

            sceUtilsBufferCopyWithRange(random, 0x14, NULL, 0, 0xE);

            for (i = 0xF; i >= 0; i--) {
                newKey[0xF - i] = random[i];
            }
            arraycopy(newKey, 0, header, 0x14, 0x10);
            for (i = 0; i < 4; i++) {
                header[0x20 + i] = 0;
            }

            // Encryption mode 0x1: encrypt with KIRK CMD4 and XOR with the given key.
            if (ctx->mode == 0x1) {
                ScrambleSD(header, 0x10, 0x4, 0x4, 0x04);
                arraycopy(header, 0, ctx->buf, 0, 0x10);
                arraycopy(header, 0, data, 0, 0x10);
                // If the key is not NULL, XOR the hash with it.
                if (key != NULL) {
                    for (i = 0; i < 16; i++) {
                        ctx->buf[i] = (byte) (ctx->buf[i] ^ key[i]);
                    }
                }
                return 0;
            } else if (ctx->mode == 0x2) { // Encryption mode 0x2: encrypt with KIRK CMD5 and XOR with the given key.
                ScrambleSD(header, 0x10, 0x100, 0x4, 0x05);
                arraycopy(header, 0, ctx->buf, 0, 0x10);
                arraycopy(header, 0, data, 0, 0x10);
                // If the key is not NULL, XOR the hash with it.
                if (key != NULL) {
                    for (i = 0; i < 16; i++) {
                        ctx->buf[i] = (byte) (ctx->buf[i] ^ key[i]);
                    }
                }
                return 0;
            } else if (ctx->mode == 0x3) { // Encryption mode 0x3: XOR with SD keys, encrypt with KIRK CMD4 and XOR with the given key.
                for (i = 0; i < 0x10; i++) {
                    header[0x14 + i] = (byte) (header[0x14 + i] ^ sdHashKey3[i]);
                }
                ScrambleSD(header, 0x10, 0xE, 0x4, 0x04);
                for (i = 0; i < 0x10; i++) {
                    header[i] = (byte) (header[i] ^ sdHashKey4[i]);
                }
                arraycopy(header, 0, ctx->buf, 0, 0x10);
                arraycopy(header, 0, data, 0, 0x10);
                // If the key is not NULL, XOR the hash with it.
                if (key != NULL) {
                    for (i = 0; i < 16; i++) {
                        ctx->buf[i] = (byte) (ctx->buf[i] ^ key[i]);
                    }
                }
                return 0;
            } else if (ctx->mode == 0x4) { // Encryption mode 0x4: XOR with SD keys, encrypt with KIRK CMD5 and XOR with the given key.
                for (i = 0; i < 0x10; i++) {
                    header[0x14 + i] = (byte) (header[0x14 + i] ^ sdHashKey3[i]);
                }
                ScrambleSD(header, 0x10, 0x100, 0x4, 0x05);
                for (i = 0; i < 0x10; i++) {
                    header[i] = (byte) (header[i] ^ sdHashKey4[i]);
                }
                arraycopy(header, 0, ctx->buf, 0, 0x10);
                arraycopy(header, 0, data, 0, 0x10);
                // If the key is not NULL, XOR the hash with it.
                if (key != NULL) {
                    for (i = 0; i < 16; i++) {
                        ctx->buf[i] = (byte) (ctx->buf[i] ^ key[i]);
                    }
                }
                return 0;
            } else if (ctx->mode == 0x6) { // Encryption mode 0x6: XOR with new SD keys, encrypt with KIRK CMD5 and XOR with the given key.
                for (i = 0; i < 0x10; i++) {
                    header[0x14 + i] = (byte) (header[0x14 + i] ^ sdHashKey3[i]);
                }
                ScrambleSD(header, 0x10, 0x100, 0x4, 0x05);
                for (i = 0; i < 0x10; i++) {
                    header[i] = (byte) (header[i] ^ sdHashKey4[i]);
                }
                arraycopy(header, 0, ctx->buf, 0, 0x10);
                arraycopy(header, 0, data, 0, 0x10);
                // If the key is not NULL, XOR the hash with it.
                if (key != NULL) {
                    for (i = 0; i < 16; i++) {
                        ctx->buf[i] = (byte) (ctx->buf[i] ^ key[i]);
                    }
                }
                return 0;
            } else { // Encryption mode 0x0: XOR with new SD keys, encrypt with KIRK CMD4 and XOR with the given key.
                for (i = 0; i < 0x10; i++) {
                    header[0x14 + i] = (byte) (header[0x14 + i] ^ sdHashKey6[i]);
                }
                ScrambleSD(header, 0x10, 0x12, 0x4, 0x04);
                for (i = 0; i < 0x10; i++) {
                    header[i] = (byte) (header[i] ^ sdHashKey7[i]);
                }
                arraycopy(header, 0, ctx->buf, 0, 0x10);
                arraycopy(header, 0, data, 0, 0x10);
                // If the key is not NULL, XOR the hash with it.
                if (key != NULL) {
                    for (i = 0; i < 16; i++) {
                        ctx->buf[i] = (byte) (ctx->buf[i] ^ key[i]);
                    }
                }
                return 0;
            }
        } else if (genMode == 0x2) { // Key generator mode 0x02 (decryption): directly XOR the data with the given key.
            // Grab the data hash (first 16-bytes).
            arraycopy(data, 0, ctx->buf, 0, 0x10);
            // If the key is not NULL, XOR the hash with it.
            if (key != NULL) {
                for (i = 0; i < 16; i++) {
                    ctx->buf[i] = (byte) (ctx->buf[i] ^ key[i]);
                }
            }
            return 0;
        } else {
            // Invalid mode.
            return -1;
        }
    }

     int hleSdRemoveValue(SDCtx2 ctx, byte *data, int length) {
        if (ctx->padSize > 0x10 || (length < 0)) {
            // Invalid key or length.
            return -1;
        } else if (((ctx->padSize + length) <= 0x10)) {
            // The key hasn't been set yet.
            // Extract the hash from the data and set it as the key.
            arraycopy(data, 0, ctx->pad, ctx->padSize, length);
            ctx->padSize += length;
            return 0;
        } else {
            // Calculate the seed.
            int seed = 0;
            switch (ctx->mode) {
                case 0x6:
                    seed = 0x11;
                    break;
                case 0x4:
                    seed = 0xD;
                    break;
                case 0x2:
                    seed = 0x5;
                    break;
                case 0x1:
                    seed = 0x3;
                    break;
                case 0x3:
                    seed = 0xC;
                    break;
                default:
                    seed = 0x10;
                    break;
            }

            // Setup the buffers. 
            byte *scrambleBuf = malloc((length + ctx->padSize) + 0x14);
            
            // Copy the previous key to the buffer.
            arraycopy(ctx->pad, 0, scrambleBuf, 0x14, ctx->padSize);
            
            // Calculate new key length.
            int kLen = ctx->padSize;          
            
            ctx->padSize += length;
            ctx->padSize &= 0x0F;
            if(ctx->padSize == 0) {
                ctx->padSize = 0x10;
            }           

            // Calculate new data length.
            length -= ctx->padSize;    
            
            // Copy data's footer to make a new key.
            arraycopy(data, length, ctx->pad, 0, ctx->padSize);
            
            // Process the encryption in 0x800 blocks.
            int blockSize = 0;
            int dataOffset = 0;
            
            while (length > 0) {
                blockSize = (length + kLen >= 0x0800) ? 0x0800 : length + kLen;            
                
                arraycopy(data, dataOffset, scrambleBuf, 0x14 + kLen, blockSize - kLen);
                int i;
                // Encrypt with KIRK CMD 4 and XOR with result.
                for (i = 0; i < 0x10; i++) {
                    scrambleBuf[0x14 + i] = (byte) (scrambleBuf[0x14 + i] ^ ctx->key[i]);
                } 
                ScrambleSD(scrambleBuf, blockSize, seed, 0x4, 0x04);             
                arraycopy(scrambleBuf, (blockSize + 0x4) - 0x14, ctx->key, 0, 0x10);
                
                // Adjust data length, data offset and reset any key length.
                length -= (blockSize - kLen);
                dataOffset += (blockSize - kLen);
                kLen = 0;               
            }      

            return 0;
        }
    }

     int hleSdGetLastIndex(SDCtx2 ctx, byte *hash, byte *key) {
        if (ctx->padSize > 0x10) {
            // Invalid key length.
            return -1;
        }

        // Setup the buffers.           
        byte scrambleEmptyBuf[0x10 + 0x14];
        byte keyBuf[0x10];            
        byte scrambleKeyBuf[0x10 + 0x14];          
        byte resultBuf[0x10];
        byte scrambleResultBuf[0x10 + 0x14];     
        byte scrambleResultKeyBuf[0x10 + 0x14];

        // Calculate the seed.
        int seed = 0;
        switch (ctx->mode) {
            case 0x6:
                seed = 0x11;
                break;
            case 0x4:
                seed = 0xD;
                break;
            case 0x2:
                seed = 0x5;
                break;
            case 0x1:
                seed = 0x3;
                break;
            case 0x3:
                seed = 0xC;
                break;
            default:
                seed = 0x10;
                break;
        }
        
        // Encrypt an empty buffer with KIRK CMD 4.
        ScrambleSD(scrambleEmptyBuf, 0x10, seed, 0x4, 0x04);
        arraycopy(scrambleEmptyBuf, 0, keyBuf, 0, 0x10);
        int i;
        // Apply custom padding management.
        byte b = ((keyBuf[0] & (byte) 0x80) != 0) ? (byte) 0x87 : 0;       
        for(i = 0; i < 0xF; i++) {
            keyBuf[i] = (byte) ((keyBuf[i] << 1) | (keyBuf[i + 1] >> 7));
        }        
        keyBuf[0xF] = (byte) ((keyBuf[0xF] << 1) ^ b);    
        
        if (ctx->padSize < 0x10) {
            byte bb = ((keyBuf[0] & (byte) 0x80) != 0) ? (byte) 0x87 : 0;       
            for(i = 0; i < 0xF; i++) {
                keyBuf[i] = (byte) ((keyBuf[i] << 1) | (keyBuf[i + 1] >> 7));
            }        
            keyBuf[0xF] = (byte) ((keyBuf[0xF] << 1) ^ bb);
            
            ctx->pad[ctx->padSize] = (byte) 0x80;
            if ((ctx->padSize + 1) < 0x10) {
                for (i = 0; i < (0x10 - ctx->padSize - 1); i++) {
                    ctx->pad[ctx->padSize + 1 + i] = 0;
                }
            }
        }
        
        // XOR previous key with new one.
        for (i = 0; i < 0x10; i++) {
            ctx->pad[i] = (byte) (ctx->pad[i] ^ keyBuf[i]);
        }
        
        arraycopy(ctx->pad, 0, scrambleKeyBuf, 0x14, 0x10);
        arraycopy(ctx->key, 0, resultBuf, 0, 0x10);
        
        // Encrypt with KIRK CMD 4 and XOR with result.
        for (i = 0; i < 0x10; i++) {
            scrambleKeyBuf[0x14 + i] = (byte) (scrambleKeyBuf[0x14 + i] ^ resultBuf[i]);
        }
        ScrambleSD(scrambleKeyBuf, 0x10, seed, 0x4, 0x04);
        arraycopy(scrambleKeyBuf, (0x10 + 0x4) - 0x14, resultBuf, 0, 0x10);
        
        // If ctx->mode is the new mode 0x6, XOR with the new hash key 5, else, XOR with hash key 2.
        if (ctx->mode == 0x6) {
            for (i = 0; i < 0x10; i++) {
                resultBuf[i] = (byte) (resultBuf[i] ^ sdHashKey5[i]);
            }
        } else {
            for (i = 0; i < 0x10; i++) {
                resultBuf[i] = (byte) (resultBuf[i] ^ sdHashKey2[i]);
            }
        }
        
        // If mode is 2, 4 or 6, encrypt again with KIRK CMD 5 and then KIRK CMD 4.
        if ((ctx->mode == 0x2) || (ctx->mode == 0x4) || (ctx->mode == 0x6)) {
            arraycopy(resultBuf, 0, scrambleResultBuf, 0x14, 0x10);
            ScrambleSD(scrambleResultBuf, 0x10, 0x100, 0x4, 0x05);           
            ScrambleSD(scrambleResultBuf, 0x10, seed, 0x4, 0x04);
            arraycopy(scrambleResultBuf, 0, resultBuf, 0, 0x10);
        }
        
        // XOR with the supplied key and encrypt with KIRK CMD 4.
        if (key != NULL) {
            for (i = 0; i < 0x10; i++) {
                resultBuf[i] = (byte) (resultBuf[i] ^ key[i]);
            }
            arraycopy(resultBuf, 0, scrambleResultKeyBuf, 0x14, 0x10);
            ScrambleSD(scrambleResultKeyBuf, 0x10, seed, 0x4, 0x04);
            arraycopy(scrambleResultKeyBuf, 0, resultBuf, 0, 0x10);
        }
        
        // Copy back the generated hash.
        arraycopy(resultBuf, 0, hash, 0, 0x10);
     
        // Clear the context fields.
        ctx->mode = 0;
        ctx->padSize = 0;
        for (i = 0; i < 0x10; i++) {
            ctx->pad[i] = 0;
        }
        for (i = 0; i < 0x10; i++) {
            ctx->key[i] = 0;
        }     
            
        return 0;
    }

     int hleSdSetMember(SDCtx1 ctx, byte *data, int length) {
        if (length <= 0) {
            return -1;
        }

        int finalSeed = 0;
        byte *dataBuf = calloc(length + 0x14,1);
        byte keyBuf[0x10 + 0x10];memset(keyBuf,0,0x20);
        byte hashBuf[0x10];

        // Copy the hash stored by hleSdCreateList.
        arraycopy(ctx->buf, 0, dataBuf, 0x14, 0x10);

		int i;
        if (ctx->mode == 0x1) {
            // Decryption mode 0x01: decrypt the hash directly with KIRK CMD7.
            ScrambleSD(dataBuf, 0x10, 0x4, 5, 0x07);
            finalSeed = 0x53;
        } else if (ctx->mode == 0x2) {
            // Decryption mode 0x02: decrypt the hash directly with KIRK CMD8.
            ScrambleSD(dataBuf, 0x10, 0x100, 5, 0x08);
            finalSeed = 0x53;
        } else if (ctx->mode == 0x3) {
            // Decryption mode 0x03: XOR the hash with SD keys and decrypt with KIRK CMD7.
            for (i = 0; i < 0x10; i++) {
                dataBuf[0x14 + i] = (byte) (dataBuf[0x14 + i] ^ sdHashKey3[i]);
            }
            ScrambleSD(dataBuf, 0x10, 0xE, 5, 0x07);
            for (i = 0; i < 0x10; i++) {
                dataBuf[i] = (byte) (dataBuf[i] ^ sdHashKey4[i]);
            }
            finalSeed = 0x57;
        } else if (ctx->mode == 0x4) {
            // Decryption mode 0x04: XOR the hash with SD keys and decrypt with KIRK CMD8.
            for (i = 0; i < 0x10; i++) {
                dataBuf[0x14 + i] = (byte) (dataBuf[0x14 + i] ^ sdHashKey3[i]);
            }
            ScrambleSD(dataBuf, 0x10, 0x100, 5, 0x08);
            for (i = 0; i < 0x10; i++) {
                dataBuf[i] = (byte) (dataBuf[i] ^ sdHashKey4[i]);
            }
            finalSeed = 0x57;
        } else if (ctx->mode == 0x6) {
            // Decryption mode 0x06: XOR the hash with new SD keys and decrypt with KIRK CMD8.
            for (i = 0; i < 0x10; i++) {
                dataBuf[0x14 + i] = (byte) (dataBuf[0x14 + i] ^ sdHashKey7[i]);
            }
            ScrambleSD(dataBuf, 0x10, 0x100, 5, 0x08);
            for (i = 0; i < 0x10; i++) {
                dataBuf[i] = (byte) (dataBuf[i] ^ sdHashKey6[i]);
            }
            finalSeed = 0x64;
        } else {
            // Decryption master mode: XOR the hash with new SD keys and decrypt with KIRK CMD7.
            for (i = 0; i < 0x10; i++) {
                dataBuf[0x14 + i] = (byte) (dataBuf[0x14 + i] ^ sdHashKey7[i]);
            }
            ScrambleSD(dataBuf, 0x10, 0x12, 5, 0x07);
            for (i = 0; i < 0x10; i++) {
                dataBuf[i] = (byte) (dataBuf[i] ^ sdHashKey6[i]);
            }
            finalSeed = 0x64;
        }

        // Store the calculated key.
        arraycopy(dataBuf, 0, keyBuf, 0x10, 0x10);

        if (ctx->unk != 0x1) {
            arraycopy(keyBuf, 0x10, keyBuf, 0, 0xC);
            keyBuf[0xC] = (byte) ((ctx->unk - 1) & 0xFF);
            keyBuf[0xD] = (byte) (((ctx->unk - 1) >> 8) & 0xFF);
            keyBuf[0xE] = (byte) (((ctx->unk - 1) >> 16) & 0xFF);
            keyBuf[0xF] = (byte) (((ctx->unk - 1) >> 24) & 0xFF);
        }

        // Copy the first 0xC bytes of the obtained key and replicate them
        // across a new list buffer. As a terminator, add the ctx->unk parameter's
        // 4 bytes (endian swapped) to achieve a full numbered list.
        for (i = 0x14; i < (length + 0x14); i += 0x10) {
            arraycopy(keyBuf, 0x10, dataBuf, i, 0xC);
            dataBuf[i + 0xC] = (byte) (ctx->unk & 0xFF);
            dataBuf[i + 0xD] = (byte) ((ctx->unk >> 8) & 0xFF);
            dataBuf[i + 0xE] = (byte) ((ctx->unk >> 16) & 0xFF);
            dataBuf[i + 0xF] = (byte) ((ctx->unk >> 24) & 0xFF);
            ctx->unk++;
        }

        arraycopy(dataBuf, length + 0x04, hashBuf, 0, 0x10);

        ScrambleSD(dataBuf, length, finalSeed, 5, 0x07);
//memcpy(data,dataBuf,length);return 0;
        // XOR the first 16-bytes of data with the saved key to generate a new hash.
        for (i = 0; i < 0x10; i++) {
            dataBuf[i] = (byte) (dataBuf[i] ^ keyBuf[i]);
        }

        // Copy back the last hash from the list to the first half of keyBuf.
        arraycopy(hashBuf, 0, keyBuf, 0, 0x10);

        // Finally, XOR the full list with the given data.
        for (i = 0; i < length; i++) {
            data[i] = (byte) (data[i] ^ dataBuf[i]);
        }

        return 0;
    }

     int hleChnnlsv_21BE78B4(SDCtx1 ctx) {
        ctx->mode = 0;
        ctx->unk = 0;
        int i;
        for(i = 0; i < 0x10; i++) {
            ctx->buf[i] = 0;
        }
        return 0;
    }
#if 0
     DecryptSavedata(byte *inbuf, int size, byte *key, int mode) {
        // Setup the crypto and keygen modes and initialize both context structs.
        int sdEncMode = 0;
        int sdGenMode = 2;
        SDCtx1 ctx1 = new SDCtx1();
        SDCtx2 ctx2 = new SDCtx2();

        // Align the buffers to 16-bytes.
        int alignedSize = ((size + 0xF) >> 4) << 4;
        byte[] outbuf = new byte[alignedSize + 0x10];
        byte[] dataBuf = new byte[alignedSize];

        // Fully copy the contents of the encrypted file.
        arraycopy(inbuf, 0, dataBuf, 0, size);

        // Check the crypto modes.
        byte[] NULLKey = new byte[0x10];
        if (key == NULLKey) {
            sdEncMode = 1;
        } else if ((mode == 1) || (mode == 2)) { // Old crypto mode (up to firmware 2.5.2).
            sdEncMode = 3;
        }

        // Call the SD functions.
        hleSdSetIndex(ctx2, sdEncMode);
        hleSdCreateList(ctx1, sdEncMode, sdGenMode, outbuf, key);
        hleSdRemoveValue(ctx2, outbuf, 0x10);
        hleSdRemoveValue(ctx2, dataBuf, alignedSize);
        hleSdSetMember(ctx1, dataBuf, alignedSize);
        arraycopy(dataBuf, 0, outbuf, 0x10, alignedSize);

        return outbuf;
    }
#endif
     //byte* DecryptSavedata(byte *inbuf, int size, byte *key, int mode) {
	main(int argc, char **argv){
		kirk_init();
		initstdio();
		FILE *f=fopen(argv[1],"rb");
		int size=filelength(fileno(f));
		char *inbuf=malloc(size);
		fread(inbuf,1,size,f);
		fclose(f);
		byte key[16];memset(key,0,16);//	BBSFM key = { 0x4B, 0x30, 0x4E, 0xBA, 0x47, 0x36, 0x44, 0x31, 0xE6, 0x33, 0x4D, 0x35, 0x48, 0xD2, 0x45, 0x30 };
		if(strcasecmp(argv[2],"NULL")){
			f=fopen(argv[2],"rb");
			fread(key,1,16,f);
			fclose(f);
		}
		f=fopen("savedata_out.bin","wb");
if(argc>3){ //enc. argv[3]=PARAM.SFO.
        int sdEncMode = 0;
        int sdGenMode = 1;
        _SDCtx1 ctx1;
        _SDCtx2 ctx2;

        // Align the buffers to 16-bytes.
        int alignedSize = ((size + 0xF) >> 4) << 4;
        byte *outbuf = malloc(alignedSize + 0x10);
        byte *dataBuf = malloc(alignedSize);

        // Fully copy the contents of the encrypted file.
        arraycopy(inbuf, 0, dataBuf, 0, size);

		int mode=0;
        // Check the crypto modes.
        byte nullKey[0x10];
        memset(nullKey,0,0x10);
        if (!memcmp(key,nullKey,0x10)) {
            sdEncMode = 1;
        } else if ((mode == 1) || (mode == 2)) { // Old crypto mode (up to firmware 2.5.2).
            sdEncMode = 3;
        }

        // Call the SD functions.
        hleSdSetIndex(&ctx2, sdEncMode);
        hleSdCreateList(&ctx1, sdEncMode, sdGenMode, outbuf, key);
        hleSdRemoveValue(&ctx2, outbuf, 0x10);
        hleSdRemoveValue(&ctx2, dataBuf, alignedSize);
        hleSdSetMember(&ctx1, dataBuf, alignedSize);
        arraycopy(dataBuf, 0, outbuf, 0x10, alignedSize);

        fwrite(outbuf,1,alignedSize+0x10,f);
}else{
		//fprintf(stderr,"%s\n",key);
        // Setup the crypto and keygen modes and initialize both context structs.
        int sdEncMode = 0;
        int sdGenMode = 2;
        _SDCtx1 ctx1;
        _SDCtx2 ctx2;

        // Align the buffers to 16-bytes.
        int alignedSize = ((size + 0xF) >> 4) << 4;
        byte *outbuf = malloc(alignedSize - 0x10);
        byte *dataBuf = malloc(alignedSize);
		int mode=0;
        // Fully copy the contents of the encrypted file.
        arraycopy(inbuf, 0, dataBuf, 0, size);

        // Check the crypto modes.
        byte nullKey[0x10];
        memset(nullKey,0,0x10);
        if (!memcmp(key,nullKey,0x10)) {
            sdEncMode = 1;
        } else if ((mode == 1) || (mode == 2)) { // Old crypto mode (up to firmware 2.5.2).
            sdEncMode = 3;
        }

        // Call the SD functions.
       hleSdSetIndex(&ctx2, sdEncMode);
        hleSdCreateList(&ctx1, sdEncMode, sdGenMode, dataBuf, key);
        hleSdRemoveValue(&ctx2, dataBuf, 0x10);
        arraycopy(dataBuf, 0x10, outbuf, 0, alignedSize - 0x10);
        hleSdRemoveValue(&ctx2, outbuf, alignedSize - 0x10);
        hleSdSetMember(&ctx1, outbuf, alignedSize - 0x10);
        fwrite(outbuf,1,size-0x10,f);
	}
		fclose(f);
	return 0;
}